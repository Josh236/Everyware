#!/bin/bash
pylint ibm_cloud_sdk_core test
